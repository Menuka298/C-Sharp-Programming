﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class payment : Form
    {
        public payment()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = (txtName.Text);
            double amu = double.Parse(txtAmount.Text);
            double date = double.Parse(txtDate.Text);

            double sum = amu * date;
            lblBalance.Text = " Mr/Mrs  : " + name + " ,  your Payment  : Rs  " + sum.ToString();
        }

        private void payment_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtAmount.Clear();
            txtDate.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
         
        }

        private void lblBalance_Click(object sender, EventArgs e)
        {

        }
    }
}
