﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class PatientDetails : Form
    {
        public PatientDetails()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose(true);
        }
        private static string connetionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\DB.mdb";
        private static OleDbConnection cnn;
        private static OleDbCommand cmd;
        private void PatientDetails_Load(object sender, EventArgs e)
        {
            cnn = new OleDbConnection(connetionString);
            cnn.Open();
            cmd = new OleDbCommand("SELECT [patientname] , [patientage], [address], [bloodgroup], [contact], [gender], [details] FROM tblPatients", cnn);
            DataSet sDs = new DataSet();
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            adapter.Fill(sDs, "tblPatients");
            dataGridView1.DataSource = sDs.Tables["tblPatients"];
            cnn.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            cnn = new OleDbConnection(connetionString);
            cnn.Open();
            cmd = new OleDbCommand("DELETE FROM tblPatients", cnn);
            cmd.ExecuteNonQuery();
            cnn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
    }
